import express from 'express';
import mysql from 'mysql';
import cors from 'cors';

const app = express();
app.use(cors());
app.use(express.json()); // Add this line to parse JSON bodies

const db = mysql.createConnection({
    host: "localhost",
    port: "3306",
    user: "root",
    password: "password",
    database: 'crud'
});

app.get('/', (req, res) => {
    const sql = "SELECT * FROM student";
    db.query(sql, (err, result) => {
        if (err) return res.json({ Message: err });
        return res.json(result);
    });
});

app.post('/student', (req, res) => {
    const { id, name, age } = req.body; 
    console.log("Request body:", req.body);
    const sql = "INSERT INTO student (id, name, age) VALUES (?,?,?)";
    db.query(sql, [id, name, age], (err, result) => {
        if (err) return res.json({ Message: err });
        return res.json({ Message: 'Student added successfully',result });
    });
});
app.put('/student/:id', (req, res) => {
    const {id} = req.params;
    const { name, age } = req.body; 
    console.log("Request body:", req.body);
    const sql ="UPDATE student SET name=?,age=? WHERE ID=?";
    db.query(sql, [name, age, id], (err, result) => {
        if (err) return res.json({ Message: err });
        return res.json({ Message: 'Student added successfully',result });
    });
});
app.delete('/student/:id', (req, res) => {
    const { id } = req.params; 
    console.log("Request body:", req.params);
    const sql ="DELETE FROM student  WHERE id=?";
    db.query(sql, [id], (err, result) => {
        if (err) return res.json({ Message: err });
        return res.json({ Message: 'Student added successfully',result});
    });
});
app.listen(3000, () => {
    console.log("Listening on port 3000");
});
