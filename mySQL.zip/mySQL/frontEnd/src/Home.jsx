import React from "react"
import axois from 'axios'
function Home(){
    const [data, setdata] = useState([])
    useInsertionEffect(()=> {
        axios.get('http://localhost:8081/')
        .then(res => setdata(res.data))
        .catch(err => console.log(err));
    }, [])
    return{
    }
}
export default Home